
<footer>
    <p><strong>kaɪrən</strong> <?php echo date('Y')?></p>
</footer>